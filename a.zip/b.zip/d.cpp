#include<iostream>
using namespace std;

class A
{public:
int a=10;
};



class B:public A{
};
   
   
   
int main(){
A p;
p.a=20;
B q;
cout<<q.a<<"\n";
}







